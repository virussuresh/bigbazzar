-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2018 at 04:32 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bigbazaar`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `address1` varchar(100) NOT NULL,
  `address2` varchar(100) NOT NULL,
  `city` varchar(20) NOT NULL,
  `county` varchar(20) NOT NULL,
  `post_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`address_id`, `order_id`, `address1`, `address2`, `city`, `county`, `post_code`) VALUES
(22, 17, '9847768509', '9867705270', 'Kathmandu', 'Baglung', '44600'),
(23, 18, '9847052854', '9851102489', 'Lalitpur', 'Lalitpur', '446001'),
(24, 19, '985745986', '9847655258', 'Pokhara', 'Kalikot', '42560');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(4) NOT NULL,
  `username` varchar(15) NOT NULL DEFAULT '',
  `password` varchar(15) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(4, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(10) NOT NULL,
  `cart_session` varchar(100) NOT NULL DEFAULT '',
  `item_id` int(10) NOT NULL DEFAULT '0',
  `item_price` float NOT NULL DEFAULT '0',
  `item_name` varchar(100) NOT NULL DEFAULT '',
  `item_quantity` int(2) NOT NULL DEFAULT '1',
  `item_total_price` float NOT NULL DEFAULT '0',
  `item_image` varchar(100) NOT NULL,
  `cart_status` varchar(10) NOT NULL,
  `order_id` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `cart_session`, `item_id`, `item_price`, `item_name`, `item_quantity`, `item_total_price`, `item_image`, `cart_status`, `order_id`) VALUES
(1, 'i3biig18tocru2m4m6rgupdn04', 43, 5000, 'Sunglass', 1, 5000, 'images/uploads/Sunglass_43_small..jpg', 'saved', '17'),
(2, 'i3biig18tocru2m4m6rgupdn04', 43, 5000, 'Sunglass', 1, 5000, 'images/uploads/Sunglass_43_small..jpg', 'saved', '18'),
(3, 'i3biig18tocru2m4m6rgupdn04', 27, 5000, 'Mens Shirt', 1, 5000, 'images/uploads/Mens_Shirt_27_small..jpg', 'saved', '19');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) UNSIGNED NOT NULL,
  `cat_name` varchar(30) NOT NULL DEFAULT '',
  `status` varchar(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`, `status`) VALUES
(22, 'Bag Collection', '1'),
(21, 'Glasses', '1'),
(19, 'Shoes', '1'),
(18, 'Shirts Collection', '1'),
(20, 'Gadgets', '1');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` bigint(20) NOT NULL,
  `item_name` varchar(250) NOT NULL DEFAULT '',
  `item_price` float NOT NULL DEFAULT '0',
  `item_desc` text NOT NULL,
  `item_status` tinyint(1) NOT NULL DEFAULT '0',
  `cat_id` int(10) NOT NULL DEFAULT '0',
  `thumbnail` varchar(100) NOT NULL DEFAULT '',
  `big_image` varchar(100) NOT NULL DEFAULT '',
  `medium_image` varchar(100) NOT NULL,
  `item_stock` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `item_price`, `item_desc`, `item_status`, `cat_id`, `thumbnail`, `big_image`, `medium_image`, `item_stock`) VALUES
(44, 'Shoes', 14000, 'Men best shoe at best price in nepal.', 0, 19, 'images/uploads/Shoes_44_small..jpg', 'images/uploads/Shoes_44..jpg', 'images/uploads/Shoes_44_med..jpg', 2),
(45, 'Laptop', 45000, 'Del genuine laptop with 8 GB RAM and 1TB Hard disk.', 0, 20, 'images/uploads/Laptop_45_small..png', 'images/uploads/Laptop_45..png', 'images/uploads/Laptop_45_med..png', 1),
(46, 'Shirt', 1200, 'Ladies shirts collection.', 0, 18, 'images/uploads/Shirt_46_small..jpg', 'images/uploads/Shirt_46..jpg', 'images/uploads/Shirt_46_med..jpg', 10),
(47, 'Bag', 49000, 'Pure leather bag for men.', 0, 22, 'images/uploads/Bag_47_small..jpg', 'images/uploads/Bag_47..jpg', 'images/uploads/Bag_47_med..jpg', 5),
(32, 'Shoes', 15000, 'Men Shoes within affordable price.', 0, 19, 'images/uploads/Shoes_32_small..jpg', 'images/uploads/Shoes_32..jpg', 'images/uploads/Shoes_32_med..jpg', 2),
(27, 'Mens Shirt', 5000, 'Best quality shirt with new looks.', 0, 18, 'images/uploads/Mens_Shirt_27_small..jpg', 'images/uploads/Mens_Shirt_27..jpg', 'images/uploads/Mens_Shirt_27_med..jpg', 2),
(28, 'Shirt', 2500, 'High quality shirt for men', 0, 18, 'images/uploads/Shirt_28_small..jpg', 'images/uploads/Shirt_28..jpg', 'images/uploads/Shirt_28_med..jpg', 1),
(29, 'Shirt', 3000, 'Black color mens shirt', 0, 18, 'images/uploads/Shirt_29_small..jpg', 'images/uploads/Shirt_29..jpg', 'images/uploads/Shirt_29_med..jpg', 5),
(30, 'Shirt', 1500, 'Ladies shirt with beautiful color combination.', 0, 18, 'images/uploads/Shirt_30_small..jpg', 'images/uploads/Shirt_30..jpg', 'images/uploads/Shirt_30_med..jpg', 2),
(31, 'Shirt', 2300, 'Professional looking shirt for ladies.', 0, 18, 'images/uploads/Shirt_31_small..jpg', 'images/uploads/Shirt_31..jpg', 'images/uploads/Shirt_31_med..jpg', 1),
(33, 'Shoes', 4000, 'Black color shoe for men.', 0, 19, 'images/uploads/Shoes_33_small..jpg', 'images/uploads/Shoes_33..jpg', 'images/uploads/Shoes_33_med..jpg', 1),
(34, 'Shoe', 1500, 'Ladies shoes at reasonable price.', 0, 19, 'images/uploads/Shoe_34_small..jpg', 'images/uploads/Shoe_34..jpg', 'images/uploads/Shoe_34_med..jpg', 2),
(35, 'Laptop', 80000, 'Acer Laptop brand new.', 0, 20, 'images/uploads/Laptop_35_small..png', 'images/uploads/Laptop_35..png', 'images/uploads/Laptop_35_med..png', 1),
(36, 'Laptop', 75000, 'Lenevo Laptop.', 0, 20, 'images/uploads/Laptop_36_small..png', 'images/uploads/Laptop_36..png', 'images/uploads/Laptop_36_med..png', 2),
(37, 'Headphone', 5000, 'Headphone brand new with 1 year warranty.', 0, 20, 'images/uploads/Headphone_37_small..jpg', 'images/uploads/Headphone_37..jpg', 'images/uploads/Headphone_37_med..jpg', 2),
(38, 'Ladies Watch', 40000, 'Watch for ladies.', 0, 20, 'images/uploads/Ladies_Watch_38_small..jpg', 'images/uploads/Ladies_Watch_38..jpg', 'images/uploads/Ladies_Watch_38_med..jpg', 4),
(39, 'Samsung Phone', 70000, 'Samsung s6 edge.', 0, 20, 'images/uploads/Samsung_Phone_39_small..jpg', 'images/uploads/Samsung_Phone_39..jpg', 'images/uploads/Samsung_Phone_39_med..jpg', 5),
(40, 'Phone', 10000, 'Nokia Phone set.', 0, 20, 'images/uploads/Phone_40_small..jpg', 'images/uploads/Phone_40..jpg', 'images/uploads/Phone_40_med..jpg', 2),
(41, 'Sunglass', 15000, 'Sunglasses for Men and Women from bigbazzar.com (Up to 54% Off)', 0, 21, 'images/uploads/Sunglass_41_small..jpg', 'images/uploads/Sunglass_41..jpg', 'images/uploads/Sunglass_41_med..jpg', 10),
(42, 'Black 56 Sunglass', 15000, 'with Graduated Grey Lenses', 0, 21, 'images/uploads/Black_56_Sunglass_42_small..jpg', 'images/uploads/Black_56_Sunglass_42..jpg', 'images/uploads/Black_56_Sunglass_42_med..jpg', 2),
(43, 'Sunglass', 5000, 'Buy 2 get 1 free', 0, 21, 'images/uploads/Sunglass_43_small..jpg', 'images/uploads/Sunglass_43..jpg', 'images/uploads/Sunglass_43_med..jpg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(10) NOT NULL,
  `cart_session` varchar(100) NOT NULL,
  `user_id` varchar(20) NOT NULL DEFAULT '0',
  `sub_total` varchar(10) NOT NULL,
  `vat` varchar(10) NOT NULL,
  `total_price` double NOT NULL DEFAULT '0',
  `order_date` varchar(50) NOT NULL DEFAULT '',
  `shipment_date` varchar(50) NOT NULL DEFAULT '',
  `order_status` varchar(15) NOT NULL DEFAULT 'New',
  `ipaddress` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `cart_session`, `user_id`, `sub_total`, `vat`, `total_price`, `order_date`, `shipment_date`, `order_status`, `ipaddress`) VALUES
(17, 'i3biig18tocru2m4m6rgupdn04', '20', '5000', '1000', 6000, '2018-05-30 16:57:53', '', 'dispatched', '::1'),
(18, 'i3biig18tocru2m4m6rgupdn04', '21', '5000', '1000', 6000, '2018-05-30 17:02:22', '', 'new', '::1'),
(19, 'i3biig18tocru2m4m6rgupdn04', '21', '5000', '1000', 6000, '2018-05-30 17:03:11', '', 'new', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL DEFAULT '',
  `user_pass` varchar(10) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `date_joined` varchar(50) NOT NULL DEFAULT '',
  `company_name` char(20) NOT NULL DEFAULT '1',
  `account_type` varchar(20) NOT NULL DEFAULT 'None',
  `status` enum('A','I') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `user_pass`, `email`, `date_joined`, `company_name`, `account_type`, `status`) VALUES
(20, 'Suresh Khattri', 'suresh123', 'sureshkhattri999@gmail.com', '2018-05-30 16:56:59', '', 'personal', 'A'),
(21, 'Hari Gauchan', 'hari123', 'hari76@gmail.com', '2018-05-30 17:01:16', 'Megha Sales', 'trade', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`address_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD UNIQUE KEY `admin_id` (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `address_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
