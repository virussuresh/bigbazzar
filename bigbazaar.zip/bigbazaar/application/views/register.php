<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url();?>css/main.css" type="text/css">

	<link rel="Stylesheet" type="text/css" href="<?php echo base_url();?>css/evoslider.css" />
	<link rel="Stylesheet" type="text/css" href="<?php echo base_url();?>css/default/default.css" />   
	
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.evoslider.lite-1.1.0.js"></script> 
</head>
<body>
	<div id="wrapper">
		<?php include("header.php"); ?>
		<?php include("slider.php"); ?>
		<div id="content">
			
			<?php include("left.php"); ?>
			<div id="right">
				<h1 class="bar">Register Here</h1>
				<?php if(validation_errors()) { ?><div id="errors"><?php echo validation_errors(); ?></div> <?php } ?>
				<?php if($this->uri->segment(2)!='') { ?><div id="errors"> Sorry - Email is already in use!</div> <?php } ?>
				
				<form action="<?=base_url();?>index.php/register" method="post" enctype="multipart/form-data" id="admin" class="wizard">
					
					<fieldset>
						<table>
							<tr>
								<td>Full Name:</td>
							</tr>
							<tr>
								<td><input name="full_name" type="text" id="full_name" value="<?=set_value('full_name');?>"> </td>
							</tr>
							
							<tr>
								<td>Account Type:</td>
							</tr>
							<tr>
								<td>
									<select <?php echo set_value('account_type'); ?>  name="account_type" id="account_type" class="cat_id">
										<option value="">Select Account Type</option>
										<option <?php echo (set_value('account_type')=='personal')?" selected=' selected'":""?> value="personal">Personal</option>
										<option <?php echo (set_value('account_type')=='trade')?" selected=' selected'":""?>  value="trade">Trade</option>
									</select>
								</td>
							</tr>
							
							<tr>
								<td>Company Name (If trade account):</td>
							</tr>
							<tr>
								<td><input name="company_name" type="text" id="company_name" value="<?=set_value('company_name');?>"></td>
							</tr>
							
							<tr>
								<td>Email Address:</td>
							</tr>
							<tr>
								<td><input name="email" type="text" id="email" value="<?=set_value('email');?>"></td>
							</tr>
							
							<tr>
								<td>Password:</td>
							</tr>
							<tr>
								<td><input name="password" type="password" id="password" value="<?=set_value('password');?>"></td>
							</tr>
							
							<tr>
								<td>Confirm Password:</td>
							</tr>
							<tr>
								<td><input name="password2" type="password" id="password2" value="<?=set_value('password2');?>"> 
									<input name="register_action" type="hidden" id="register_action" value="true" />
								</td>
							</tr>
							
							<tr>
								<td><input type="submit" name="submit" value="Sign Up" style="background: #4D86BE;
									padding: 8px;
									border: 1px solid #4D86BE;
									border-radius: 5px;
									cursor: pointer;
									color: white;"></td>
							</tr>
							
						</table>
					</fieldset>
				</div>		
				<div class="clear"></div>
				<?php include("footer.php"); ?>
			</div>
			
		</div>
	</body>
	</html> 