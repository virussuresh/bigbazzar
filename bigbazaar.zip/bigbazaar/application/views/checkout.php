<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url();?>css/main.css" type="text/css">

	<link rel="Stylesheet" type="text/css" href="<?php echo base_url();?>css/evoslider.css" />
	<link rel="Stylesheet" type="text/css" href="<?php echo base_url();?>css/default/default.css" />   
	
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery-1.7.1.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>js/jquery.evoslider.lite-1.1.0.js"></script> 
</head>
<body>
	<div id="wrapper">
		<?php include("header.php"); ?>
		<?php include("slider.php"); ?>
		<div id="content">
			
			<?php include("left.php"); ?>
			<div id="right">
				<h1 class="bar">Checkout</h1>
				<?php if(validation_errors()) { ?><div id="errors"><?php echo validation_errors(); ?></div> <?php } ?>
				<form action="<?=base_url();?>index.php/front/order_step2" method="post" enctype="multipart/form-data" id="admin" class="wizard">
					
					<fieldset>	<strong> Delivery Address </strong>				
						<table>
							<tr>
								<td>Home Phone:</td>
							</tr>
							<tr>
								<td><input name="address1" type="text" id="address1" value="<?=set_value('address1');?>"></td>
							</tr>
							<tr>
								<td>
									Mobile:
								</td>
							</tr>
							<tr>
								<td>
									<input name="address2" type="text" id="address2" value="<?=set_value('address2');?>">
								</td>
							</tr>
							



							<tr>
								<td>Town/City:</td>

							</tr>
							<tr><td><input name="city" type="text" id="city" value="<?=set_value('city');?>"></td> </tr>
							<tr>
								<td>District</td>
							</tr>
							<tr>
								<td>
									<select name="districts" id="districts" class="cat_id" >										
										<optgroup label="District">
											<option>Achham</option>
											<option>Arghakhanchi </option>
											<option>Baglung </option>
											<option>Baitadi</option>
											<option>Bajhang</option>
											<option>Bajura </option>
											<option>Banke</option>
											<option>Bara</option>
											<option>Bardiya</option>   
											<option>Bhaktapur</option>
											<option>Bhojpur </option>
											<option>Chitwan </option>
											<option>Dadeldhura</option>
											<option>Dailekh </option>
											<option>Dang Deokhuri</option>
											<option>Darchula</option>
											<option>Dhading</option>
											<option>Dhankuta</option>
											<option>Dhanusa</option>
											<option>Dolakha</option>
											<option>Dolpa</option>
											<option>Doti</option>
											<option>Gorkha</option>
											<option>Gulmi</option>
											<option>Humla</option>
											<option>Ilam</option>
											<option>Jajarkot</option>
											<option>Jhapa</option>
											<option>Jumla</option>
											<option>Kailali</option>
											<option>Kalikot</option>
											<option>Kanchanpur</option>                                  
											<option>Kapilvastu </option>
											<option>Kaski </option>
											<option>Kathmandu</option>
											<option>Kavrepalanchok</option>       
											<option>Khotang</option>
											<option>Lalitpur</option>
											<option>Lamjung</option>       
											<option>Mahottari</option>
											<option>Makwanpur</option>
											<option>Manang</option>
											<option>Morang</option>
											<option>Mugu</option>
											<option>Mustang</option>
											<option>Myagdi</option>
											<option>Nawalparasi</option>
											<option>Nuwakot</option>
											<option>Okhaldhunga</option>
											<option>Palpa</option>
											<option>Panchthar</option>
											<option>Parbat</option>
											<option>Parsa</option>
											<option>Pyuthan</option>
											<option>Ramechhap</option>
											<option>Rasuwa</option>
											<option>Rautahat</option>
											<option>Rolpa</option>
											<option>Rukum</option>
											<option>Rupandehi</option>
											<option>Salyan</option>
											<option>Sankhuwasabha</option>
											<option>Saptari</option>
											<option>Sarlahi</option>
											<option>Sindhuli</option>
											<option>Sindhupalchok</option>
											<option>Siraha</option>
											<option>Solukhumbu</option>
											<option>Sunsari</option>
											<option>Surkhet</option>
											<option>Syangja</option>
											<option>Tanahu</option>
											<option>Taplejung</option>
											<option>Terhathum</option>
											<option>Udayapur</option>							
										</optgroup>
									</select>
								</td>
							</tr>

							<tr>
								<td>Postcode:</td>
							</tr>

							<tr>
								<td><input name="post_code" type="text" id="post_code" value="<?=set_value('post_code');?>"></td>
							</tr>																
							<tr>
								<td>
									<h2>Order Summary</h2>
									<?php
									if($products!='empty')
									{
										?>
										<table id="cart">
											<thead>
												<th>Product</th>
												<th class="qty-column">Qty</th>
												<th>Price</th>
												<th>Total</th>
											</thead>
											<tbody>
												<?php 
												$total_price	=	0;
												foreach($products as $product) {	
													$total_price += $product->item_total_price;
													?>
													<tr>
														<td><?=$product->item_name;?></td>
														<td><?=$product->item_quantity;?></td>
														<td>Rs. <?=number_format($product->item_price,2);?></td>
														<td>Rs. <?=number_format($product->item_total_price,2);?></td>
													</tr>
													<?php } ?>  
													<tr>
														<td colspan="2" class="hidden"></td>
														<td><strong>Sub Total</strong></td>
														<td>Rs.<?=number_format($total_price,2);?></td>
													</tr>
													<tr>
														<td colspan="2" class="hidden"></td>
														<td><strong>Shipping Charge (20%)</strong></td>
														<td>Rs. <?php $vat = ($total_price*(0.2)); echo number_format($vat,2);?></td>
													</tr>
													<tr>
														<td colspan="2" class="hidden"></td>
														<td><strong>Total</strong></td>
														<td>Rs.<?=number_format(($total_price+$vat),2);?></td>
													</tr>
												</tbody>
											</table>
											<?php } 
											else header("Location:".base_url()); ?>
											<input name="vat" type="hidden" id="vat" value="<?=$vat;?>" />
											<input name="sub_total" type="hidden" id="sub_total" value="<?=$total_price;?>" />
											<input name="total_price" type="hidden" id="total_price" value="<?=$total_price+$vat;?>" />
											<input name="checkout_action" type="hidden" id="checkout_action" value="true" />
										</td>
									</tr>

									<tr>
										<td><input type="submit" value="Send Order" style="background: #4D86BE;
											padding: 8px;
											border: 1px solid #4D86BE;
											border-radius: 5px;
											cursor: pointer;
											color: white;">
										</td>
									</tr>
								</table>
							</fieldset>

