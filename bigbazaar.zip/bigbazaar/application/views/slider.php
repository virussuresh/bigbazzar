<div id="mySlider" class="evoslider default"> <!-- start evo slider -->

    <dl>
    
	    <dt>slide one</dt>
	    <dd>
	       <img src="<?php echo base_url();?>images/slider/1.png">	        
	    </dd>
	
	    <dt>slide two</dt>
	    <dd>
	       <img src="<?php echo base_url();?>images/slider/2.png">	       
	    </dd>
	
	    <dt>slide three</dt>
	    <dd>	        
	       <img src="<?php echo base_url();?>images/slider/3.png">	    
	    </dd>
	
	   <!--  <dt>slide four</dt>
	    <dd>        
	       slide four content       
	    </dd> 
	    
	    <dt>slide five</dt>
	    <dd>
	       slide five content	      
	    </dd> -->
	     	
    </dl>

</div> <!-- end evo slider -->

<script type="text/javascript">
            
    $("#mySlider").evoSlider({
        mode: "scroller",                  // Sets slider mode ("accordion", "slider", or "scroller")
        width: 960,                         // The width of slider
        height: 250,                        // The height of slider
        slideSpace: 5,                      // The space between slides
    
        mouse: true,                        // Enables mousewheel scroll navigation
        keyboard: true,                     // Enables keyboard navigation (left and right arrows)
        speed: 500,                         // Slide transition speed in ms. (1s = 1000ms)
        easing: "swing",                    // Defines the easing effect mode
        loop: true,                         // Rotate slideshow
    
        autoplay: true,                     // Sets EvoSlider to play slideshow when initialized
        interval: 50000,                     // Slideshow interval time in ms
        pauseOnHover: true,                 // Pause slideshow if mouse over the slide
        pauseOnClick: true,                 // Stop slideshow if playing
        
        directionNav: true,                 // Shows directional navigation when initialized
        directionNavAutoHide: false,        // Shows directional navigation on hover and hide it when mouseout
    
        controlNav: true,                   // Enables control navigation
        controlNavAutoHide: false           // Shows control navigation on mouseover and hide it when mouseout 
    });                                
    
</script>