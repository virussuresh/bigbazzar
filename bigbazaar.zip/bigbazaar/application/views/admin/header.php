<?php
//if($this->session->userdata('admin')=='')
   // header("Location:".base_url()."index.php/admin/");
?>
<div id="header">
				<div id="logo">
					<a href="<?php echo base_url();?>index.php/admin"><img src="<?php echo base_url();?>images/home/logo.png" style="width: 200px;" alt="Jenisha Shakya" /></a>
				</div>
			</div>
			<div id="menu">
				<ul>
					<li><a href="#">Dashboard</a></li>
					<!-- <li><a href="#">Our Products</a></li> -->
					<!-- <li><a href="#">My Cart</a></li> -->
					<!-- <li><a href="#">Contact Us</a></li> -->
                    <?php if($this->session->userdata('admin')!='')
					{
					?>
                    <li><a href="<?php echo base_url();?>index.php/admin/logout">Logout</a></li>
                    <?php } ?>
				</ul>
			</div>