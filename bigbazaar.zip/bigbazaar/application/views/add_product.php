<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url();?>css/main.css" type="text/css">

    <link rel="Stylesheet" type="text/css" href="<?php echo base_url();?>css/evoslider.css" />
    <link rel="Stylesheet" type="text/css" href="<?php echo base_url();?>css/default/default.css" />   
    
    <script type="text/javascript" src="<?php echo base_url();?>js/jquery-1.7.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>js/jquery.easing.1.3.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>js/jquery.evoslider.lite-1.1.0.js"></script> 
	</head>
<body>
	<div id="wrapper">
			<?php include("header.php"); ?>
			<?php include("slider.php"); ?>
			<div id="content" class="checkout">
				
				<?php include("dashboard/left.php"); ?>
				<div id="right">
				  <h1 class="bar">Add New Product</h1>
                  	
					<?php if(validation_errors()) { ?><div id="errors"><?php echo validation_errors(); ?></div> <?php } ?>
                	<?php if($this->uri->segment(4)!='') { ?><div id="errors"> Sorry - Category Already Exists</div> <?php } ?>
                    
				  <form action="<?php echo base_url();?>index.php/user/add_product" method="post" enctype="multipart/form-data" class="wizard">
				  
				  
				  <fieldset>
				  	
					<table>
						<tr>
							<td>Product Title</td>
						</tr>
						<tr>
							<td>
								<input name="title" type="text" id="title"  value="<?=set_value('title');?>"/>
							</td>
						</tr>
						
						<tr>
							<td>Product Price:</td>
						</tr>
						<tr>
							<td>
							 <input name="price" type="text" id="price" value="<?=set_value('price');?>"/>
							</td>
						</tr>
						
						<tr>
							<td>Stock:</td>
						</tr>
						<tr>
							<td><input name="stock" type="text" id="stock" value="<?=set_value('stock');?>" /></td>
						</tr>
						
						<tr>
							<td>Photo:</td>
						</tr>
						<tr>
							<td><input type="file" name="file" id="file" /></td>
						</tr>
						
						<tr>
							<td>Category:</td>
						</tr>
						
						<tr>
								<td>
									 <select name="cat_id" id="cat_id" class="dropdown">
							  <?php
							  
							 $categories = $this->admin_model->getAllCategories();
							 foreach($categories as $category)
							 {
							 ?>
								<option value="<?php echo $category->cat_id; ?>"><?php echo $category->cat_name; ?></option>
								
							  <?php
							  }
							  ?>  
							  </select>
								</td>
						</tr>
						
						<tr>
							<td>Description:</td>
						</tr>
						<tr>
							<td>
								 <textarea name="desc" id="desc"><?=set_value('company_name');?></textarea>
							</td>
						</tr>
						<tr>
							<td>
								<input type="submit" name="submit" value="Add Product" style="background: #4D86BE;
									padding: 8px;
									border: 1px solid #4D86BE;
									border-radius: 5px;
									cursor: pointer;
									color: white;" />
                                    <input type="hidden" name="action" value="1" />
							</td>
						</tr>
					</table>
					
					
				  </fieldset>
				  
				   <!-- <p>
				      <label>Product Title:</label>
				      <input name="title" type="text" id="title"  value="<?=set_value('title');?>"/>
			        </p>
				    <p>
				      <label>Product Price:</label>
				      <input name="price" type="text" id="price" value="<?=set_value('price');?>"/>
			        </p>
				    <p>
				      <label>Stock:</label>
				      <input name="stock" type="text" id="stock" value="<?=set_value('stock');?>" />
			        </p>
				    <p>
				      <label>Photo:</label>
				      <input type="file" name="file" id="file" />
			        </p>
				    <p>
				      <label>Category:</label>
				      <select name="cat_id" id="cat_id">
                      <?php
					  
					 $categories = $this->admin_model->getAllCategories();
					 foreach($categories as $category)
					 {
					 ?>
				      	<option value="<?php echo $category->cat_id; ?>"><?php echo $category->cat_name; ?></option>
                        
                      <?php
					  }
					  ?>  
			          </select>
			        </p>
				    <p>
				      <label>Description:</label>
				      <textarea name="desc" id="desc"><?=set_value('company_name');?></textarea>
			        </p>
				    <input type="submit" name="submit" value="Add Product" />
                                    <input type="hidden" name="action" value="1" />
									-->
			      </form>
			  </div>
<div class="clear"></div>
				<div id="footer">
			</div>
			</div>
	
	</div>
</body>
</html>