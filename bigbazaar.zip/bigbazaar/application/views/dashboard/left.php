<?php 
 // if($this->session->userdata('users')=='')
 //   redirect(base_url()."index.php/users/login");
?>
<div id="left">
					<h1 class="bar">Customer Admin</h1>
					<ul id="cats">
						<li><a href="<?php echo base_url();?>index.php/user/products">Products</a></li>
					</ul>
				</div>