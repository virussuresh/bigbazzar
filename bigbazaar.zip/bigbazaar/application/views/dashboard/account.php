<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url();?>css/main.css" type="text/css">
	</head>
<body>
	<div id="wrapper">
			<?php $this->load->view("header"); ?>
	  <div id="content" class="checkout">
			  
			  <div id="left">
			    <h1 class="bar">Customer Dashboard</h1>
			    <ul id="cats">
			      <li><a href="<?=base_url();?>index.php/user">My Orders</a></li>
			      <li><a href="<?=base_url();?>index.php/user/account">Update Account</a></li>
		        </ul>
	    </div>
			  <div id="right">
					<h1 class="bar">Update Account</h1>
                    <?php if(validation_errors()) { ?><div id="errors"><?php echo validation_errors(); ?></div> <?php } ?>
                <?php if($this->uri->segment(3)!='') { ?><div id="success"> Account Information is Updated!</div> <?php } ?>
				
		  <form action="<?=base_url();?>index.php/user/account" method="post" enctype="multipart/form-data" id="admin" class="wizard">
			
			<fieldset>
				<table>
					<tr>
						<td>Full Name:</td>
					</tr>
					<tr>
						<td><input name="full_name" type="text" id="full_name" value="<?=$this->session->userdata('full_name');?>"></td>
					</tr>
					
					
					<tr>
						<td>Account Type:</td>
					</tr>
					<tr>
						<td>
							<select name="account_type" id="account_type" class="cat_id">
                            	<option value="">Select Account Type</option>
								<option value="personal" <?php if($this->session->userdata('account_type')=='personal') echo 'selected="selected"';?>>Personal</option>
								<option value="trade" <?php if($this->session->userdata('account_type')=='trade') echo 'selected="selected"';?>>Trade</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>Company Name:</td>
					</tr>
					<tr>
						<td><input name="company_name" type="text" id="company_name" value="<?=$this->session->userdata('company_name');?>"></td>
					</tr>
					
					<tr>
						<td>Email Address:</td>
					</tr>
					<tr>
						<td><input name="email" type="text" id="email" value="<?=$this->session->userdata('email');?>"></td>
					</tr>
					
					<tr>
						<td>Password</td>
					</tr>
					<tr>
						<td><input name="password" type="password" id="password"> </td>
					</tr>
					
					<tr>
						<td> Conform Password</td>
					</tr>
					<tr>
						<td>
							<input name="password2" type="password" id="password2"> 
		      <input name="update_action" type="hidden" id="update_action" value="true" />
						</td>
					</tr>
					
					<tr>
					<td>
						 <input type="submit" name="submit" value="Update" style="background: #4D86BE;
									padding: 8px;
									border: 1px solid #4D86BE;
									border-radius: 5px;
									cursor: pointer;
									color: white;" />					
					</td>
					</tr>
				</table>
			</fieldset>
							
			  </div>
			  <div class="clear"></div>
			  <?php $this->load->view("footer"); ?>
	  </div>
	</div>
</body>
</html>