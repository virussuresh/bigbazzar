<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title></title>
	<link rel="stylesheet" href="<?php echo base_url();?>css/main.css" type="text/css">
	</head>
<body>
	<div id="wrapper">
			<?php include("header.php"); ?>
			<div id="content">
								
				<div>
					<h1 class="bar">Help Desk</h1>
					<h2>Welcome to our Cart.</h2>
					<br>
					<p>1. You can add product to cart firstly.Then you have to checkout for the order confirmation.</p>
					<br>
					<p>2. For the order confirmation you have to pay certain amount as advance or you can pay all amount regarding products.</p><br>

					<p>3. Please login with you id and provide the correct address and contact for product delivary.</p><br>

					<p>4. If you don't have login id simply you can register your login id.      
					<a href="<?php echo base_url();?>index.php/register">Click Here For Registration</a></p>

					<p>Thank you !!!</p>
				</div>		
				<div class="clear"></div>
				<?php include("footer.php"); ?>
			</div>
	
	</div>
</body>
</html>