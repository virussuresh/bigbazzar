<div id="footer" align="center">
		<address>
<p> Copyright © 2018 - BIGBAZAAR NAYA NEPAL KO BAZAAR. All rights reserved. </p> 
		<p> Follow us on </p>
			<p>
			<a href="http://www.facebook.com"><img src="<?php echo base_url(); ?>images/logos/facebook.jpg" alt="Facebook"></a> &nbsp;
			<a href="http://www.twitter.com"><img src="<?php echo base_url(); ?>images/logos/twitter.png" alt="Twitter"> </a> &nbsp;
			<a href="http://www.gmail.com"><img src="<?php echo base_url(); ?>images/logos/google.png" alt="Gmail"> </a> &nbsp;
			<a href="http://www.instagram.com"><img src="<?php echo base_url(); ?>images/logos/instagram.png" alt="Instagram"> </a>
			</p>
		</address>
</div>