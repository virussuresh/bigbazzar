<?php 
echo "<pre>";
print_r($cart_products);
echo "</pre>";
?>