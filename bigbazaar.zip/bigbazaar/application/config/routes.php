<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$route['default_controller'] = "front";
$route['404_override'] = '';
$route['category/(:any)'] = "front/category";
$route['details/(:any)'] = "front/details";
$route['buy/(:any)'] = "front/buy";
$route['cart/(:any)'] = "front/cart";
$route['cart'] = "front/cart";
$route['checkout'] = "front/checkout";
$route['order_step2'] = "front/order_step2";
$route['login'] = "front/login";
$route['login/(:any)'] = "front/login";
$route['signout'] = "front/signout";
$route['register'] = "front/register";
$route['register(:any)'] = "front/register";
$route['account'] = "front/account";
$route['confirm'] = "front/confirm";

