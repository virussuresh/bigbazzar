<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Invoice extends CI_Controller {

	public function checkout()
	{
		// $data['first'] = "Suresh";
		// $this->load->view('invoice');
		// echo $quantity;
		// echo $id;
	}

}

/* End of file invoice.php */
/* Location: ./application/controllers/invoice.php */